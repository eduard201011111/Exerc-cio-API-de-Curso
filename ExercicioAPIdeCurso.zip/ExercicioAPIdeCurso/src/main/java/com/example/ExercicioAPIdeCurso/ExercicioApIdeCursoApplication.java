package com.example.ExercicioAPIdeCurso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioApIdeCursoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioApIdeCursoApplication.class, args);
	}

}
