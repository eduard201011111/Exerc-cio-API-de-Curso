package com.example.ExercicioAPIdeCurso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioApIdeCursoApplicationTests {

	@Test
	void contextLoads() {
	}

}
